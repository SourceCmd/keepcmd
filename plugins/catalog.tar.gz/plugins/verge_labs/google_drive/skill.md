---
name: google_drive
description: >
  Use when reading or writing files in a Google Drive account via a
  hearth resource connection — including editing the contents of native
  Google Docs, Sheets, and Slides. Covers listing, searching, downloading,
  uploading, organising, and editing files through the google_drive plugin.
---

# Google Drive plugin

Invoke via `hearth resource invoke <connection> <verb> '<args-json>'`.

`<connection>` is the name shown in your resource list — either the slug
(e.g. `someones_drive`) or the connection UUID. Both resolve. Examples below
use `someones_drive`; substitute the connection you were actually granted.

## Passing arguments

Args are **one JSON object**, quoted as a single shell argument. There is no
`--arg` flag. Omit the object entirely for a verb that takes no args:

```
hearth resource invoke someones_drive list_files
hearth resource invoke someones_drive get_file_metadata '{"file_id":"<id>"}'
```

Args whose name ends in `_json` take a **string containing JSON**, so that
JSON is escaped inside the outer object (`"items_json": "[{\"id\":\"a\"}]"`,
not a nested array). No Drive verb currently takes a `_json` arg — every arg
here is a plain string — but the rule holds if one is added.

## Finding files

Start with a search rather than a listing when you know what you're looking for:

```
hearth resource invoke someones_drive search_files '{"query":"name contains '\''budget'\''"}'
hearth resource invoke someones_drive search_files '{"query":"fullText contains '\''Q3 revenue'\''"}'
hearth resource invoke someones_drive search_files '{"query":"mimeType = '\''text/plain'\''"}'
```

Drive query syntax uses single quotes, which collide with the single quotes
wrapping the JSON. The `'\''` sequence above closes, escapes, and reopens the
shell quote. Double-quoting the whole argument and escaping the inner double
quotes works too:

```
hearth resource invoke someones_drive search_files "{\"query\":\"name contains 'budget'\"}"
```

Queries follow Google's Drive query syntax:
https://developers.google.com/drive/api/guides/search-files

To list the contents of a known folder, use the folder's Drive ID (from its
URL or from a previous search result):

```
hearth resource invoke someones_drive list_folder_contents '{"folder_id":"1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgVE2upms"}'
```

Pass `"folder_id": "root"` for the top of My Drive. Omit `folder_id` entirely
to list the connection's configured base folder (or My Drive root if the
connection has none set):

```
hearth resource invoke someones_drive list_folder_contents
```

## Reading file content

For plain text, Markdown, code, CSV, PDF — use `download_file`:

```
hearth resource invoke someones_drive download_file '{"file_id":"<id>"}'
```

For Google Workspace files (Docs, Sheets, Slides) — use `export_file` with
a target MIME type:

```
# Google Doc → plain text
hearth resource invoke someones_drive export_file '{"file_id":"<id>","mime_type":"text/plain"}'

# Google Doc → Word
hearth resource invoke someones_drive export_file '{"file_id":"<id>","mime_type":"application/vnd.openxmlformats-officedocument.wordprocessingml.document"}'

# Google Sheet → CSV
hearth resource invoke someones_drive export_file '{"file_id":"<id>","mime_type":"text/csv"}'

# Any file → PDF
hearth resource invoke someones_drive export_file '{"file_id":"<id>","mime_type":"application/pdf"}'
```

`download_file` on a Google Workspace file returns an error — use `export_file`
for those types.

## Getting a file's metadata

Before moving, renaming, or trashing a file, read its current state:

```
hearth resource invoke someones_drive get_file_metadata '{"file_id":"<id>"}'
```

The response includes `parents` (the current parent folder IDs) — you need
this for `move_file`.

## Creating files

`create_file` creates a metadata-only record and returns the new file's `id`.
`parent_id` is optional: omit it to create the file in the connection's
configured base folder (or My Drive root if none is set), or pass `"root"`
for My Drive root explicitly.

```
# Create an empty text file
hearth resource invoke someones_drive create_file '{
  "name": "notes.md",
  "mime_type": "text/markdown",
  "parent_id": "root"
}'

# Create an empty Google Doc
hearth resource invoke someones_drive create_file '{
  "name": "Draft",
  "mime_type": "application/vnd.google-apps.document",
  "parent_id": "<folder_id>"
}'
```

To set the file's content immediately, follow with `upload_file_content`:

```
hearth resource invoke someones_drive upload_file_content '{
  "file_id": "<id>",
  "mime_type": "text/markdown",
  "content": "# My document\n\nContent here."
}'
```

`upload_file_content` replaces the entire file content. It works for plain
text and other non-binary formats. For Google Docs/Sheets, write to a plain
text file and let the user convert, or use the Docs API (not this plugin).

## Organising files

Rename:
```
hearth resource invoke someones_drive rename_file '{"file_id":"<id>","name":"New name.md"}'
```

Move (requires the current parent ID — get it from `get_file_metadata`):
```
hearth resource invoke someones_drive move_file '{
  "file_id": "<id>",
  "new_parent_id": "<destination_folder_id>",
  "old_parent_id": "<current_parent_id>"
}'
```

Create a folder (`parent_id` optional — omit it to create inside the
connection's base folder):
```
hearth resource invoke someones_drive create_folder '{"name":"2026 Reports","parent_id":"root"}'
```

Trash (recoverable from Drive's Trash):
```
hearth resource invoke someones_drive trash_file '{"file_id":"<id>"}'
```

Trashing is always preferred over permanent deletion. There is no
permanent-delete verb — use the Drive web UI for that.

## Sharing files

```
# Share with a specific user
hearth resource invoke someones_drive share_file '{
  "file_id": "<id>",
  "role": "writer",
  "type": "user",
  "email_address": "colleague@example.com"
}'

# Share with everyone in a domain
hearth resource invoke someones_drive share_file '{
  "file_id": "<id>",
  "role": "reader",
  "type": "domain",
  "email_address": "vergelabs.org"
}'

# Make publicly readable
hearth resource invoke someones_drive share_file '{
  "file_id": "<id>",
  "role": "reader",
  "type": "anyone",
  "email_address": ""
}'
```

Roles: `reader`, `commenter`, `writer`, `fileOrganizer`, `organizer`, `owner`.

`email_address` is required on every `share_file` call — pass an empty string
when `type` is `anyone`.

## Editing Google Docs, Sheets & Slides

Beyond storing files, this plugin edits the *contents* of native Google
Workspace files through the Docs, Sheets, and Slides APIs. The verbs are
prefixed by type: `doc_*`, `sheet_*`, `slides_*`.

Create a native file and edit it, or edit an existing one by its ID:

```
# Create an empty Google Doc, capture its id from the response
hearth resource invoke someones_drive create_file '{"name":"Neighbor letter","mime_type":"application/vnd.google-apps.document"}'
# Edit it by that id
hearth resource invoke someones_drive doc_append_text '{"document_id":"<id>","text_json":"\"Dear neighbor,\\n\\nThanks for ...\""}'
```

(create_file's `parent_id` is optional — omit it to land in the connection's
base folder.)

### The `_json` text rule — read this first

Editing request bodies are assembled as raw JSON and the engine does **not**
escape your values. So every free-text field is passed as a `_json` argument
whose value is the **JSON encoding** of your text — i.e. run the text through a
JSON string encoder, surrounding quotes included. The plain word `Hello`
becomes the value `"Hello"`; multi-line text keeps its `\n` escapes. This lets
your content carry quotes, newlines, and Unicode safely. Spreadsheet data uses
the same rule via `values_json` (a JSON-encoded 2D array of rows).

Concretely, to append the two lines `Dear neighbor,` / `Thanks for ...` you set
`text_json` to `"Dear neighbor,\n\nThanks for ..."` — which, once that value is
itself placed inside the argument object, appears as the doubly-escaped
`"\"Dear neighbor,\\n\\nThanks for ...\""` shown above. When in doubt, JSON-
encode the text once and let the argument object's own JSON quoting stack on
top.

### Google Docs

To READ a Doc's text, prefer `export_file` (Doc → text/plain); use `doc_get`
only when you need the character indices for precise edits (it returns the full
structured document).

```
# Append text to the end of the doc
hearth resource invoke someones_drive doc_append_text '{"document_id":"<id>","text_json":"\"\\n## Next steps\\n\""}'

# Fill a placeholder throughout the doc (case-sensitive find/replace)
hearth resource invoke someones_drive doc_replace_text '{"document_id":"<id>","find_json":"\"[[NAME]]\"","replace_json":"\"Jane Doe\""}'

# Delete text by replacing it with the empty string
hearth resource invoke someones_drive doc_replace_text '{"document_id":"<id>","find_json":"\"DRAFT — \"","replace_json":"\"\""}'
```

`doc_replace_text` is the workhorse for template documents: author a Doc with
`[[PLACEHOLDER]]` tokens, then replace each one.

### Google Sheets

`range` is A1 notation, e.g. `Sheet1!A1:D100`. If a tab name contains spaces or
punctuation, percent-encode the range (space → `%20`, `'` → `%27`); simple
ranges need no encoding.

```
# Discover the tab names first
hearth resource invoke someones_drive sheet_get '{"spreadsheet_id":"<id>"}'

# Read a range
hearth resource invoke someones_drive sheet_read_range '{"spreadsheet_id":"<id>","range":"Sheet1!A1:C10"}'

# Overwrite a specific range (values_json is a JSON 2D array of rows)
hearth resource invoke someones_drive sheet_update_range '{"spreadsheet_id":"<id>","range":"Sheet1!A2","values_json":"[[\"Item\",\"Qty\"],[\"Bolts\",40]]"}'

# Clear a range's values (formatting is kept)
hearth resource invoke someones_drive sheet_clear_range '{"spreadsheet_id":"<id>","range":"Sheet1!A2:C99"}'

# Add a new tab
hearth resource invoke someones_drive sheet_add_tab '{"spreadsheet_id":"<id>","title":"2026 Budget"}'
```

`sheet_update_range` writes exactly where you point it: the values land at the
range's top-left cell and fill right and down, overwriting whatever is there.
Values are interpreted as if typed into the UI — `42` becomes a number,
`2026-01-01` a date, a string starting with `=` a formula.

#### Adding a row to the bottom of a list — read this trap first

`sheet_append_rows` is meant for this, but its `range` is **not where the value
is written** — the Sheets API uses it only to *find the table*, then appends
after that table's last row. The catch that bites: **if your range anchors on an
empty cell, the API decides there's no table there and writes the value into
that cell.** Passing `Sheet1!A1` is the classic mistake — in any grid whose
top-left corner is blank (a people-×-options matrix, a sheet with a title row,
headers that start in row 2), A1 is empty and your row lands in A1, clobbering
the corner.

Two safe ways to add a row:

- **Deterministic — preferred once you've read the sheet.** `sheet_read_range`
  already told you how far the data goes; write to the next empty row
  explicitly. If the last item sits in A23, add the new one at A24:
  ```
  hearth resource invoke someones_drive sheet_update_range '{"spreadsheet_id":"<id>","range":"Sheet1!A24","values_json":"[[\"New item\"]]"}'
  ```
- **Append with a range that overlaps the data** — give append a whole column or
  the table's column span, never a single cell, so it can locate the real last
  row:
  ```
  hearth resource invoke someones_drive sheet_append_rows '{"spreadsheet_id":"<id>","range":"Sheet1!A:A","values_json":"[[\"New item\"]]"}'
  ```
  Use `Sheet1!A:L` when the row spans several columns.

Rule of thumb: **never anchor `sheet_append_rows` at a lone cell.** Target a
column range that already contains data, or read the sheet and
`sheet_update_range` at the next empty row.

### Google Slides

```
# Inspect slides and their element objectIds
hearth resource invoke someones_drive slides_get '{"presentation_id":"<id>"}'

# Fill placeholders across the whole deck (great for template decks)
hearth resource invoke someones_drive slides_replace_text '{"presentation_id":"<id>","find_json":"\"{{CLIENT}}\"","replace_json":"\"The Smiths\""}'

# Add a slide (layout optional; defaults to TITLE_AND_BODY)
hearth resource invoke someones_drive slides_add_slide '{"presentation_id":"<id>","layout":"TITLE_ONLY"}'
```

To put fresh text on a new slide, add the slide, then either run
`slides_replace_text` against its layout placeholder text, or read `slides_get`
for the new text box's objectId. To insert into a specific shape by its
objectId, use `slides_insert_text`:

```
hearth resource invoke someones_drive slides_insert_text '{"presentation_id":"<id>","object_id":"<shape_object_id>","text_json":"\"Q3 Results\""}'
```

### Copying files (templates)

`copy_file` duplicates a file — the backbone of template workflows: keep a
master template Doc/Sheet, copy it, then fill the copy with `doc_replace_text` /
`sheet_update_range`.

```
hearth resource invoke someones_drive copy_file '{"file_id":"<template_id>","name":"Invoice — Smith"}'
# then edit the returned copy's id
```

`parent_id` is optional — omit it to land in the base folder.

### Comments

Read a file's comment thread, add a comment, or reply to one.

```
hearth resource invoke someones_drive comment_list '{"file_id":"<id>"}'
hearth resource invoke someones_drive comment_create '{"file_id":"<id>","content_json":"\"Looks good — one typo in para 2.\""}'
hearth resource invoke someones_drive comment_reply '{"file_id":"<id>","comment_id":"<comment_id>","content_json":"\"Fixed, thanks.\""}'
```

Comment and reply text follow the same `_json` rule.

### Precise Docs edits

When append and find/replace aren't enough, edit by character index — get the
indices from `doc_get`:

```
# Insert text at an index (1 = start of body)
hearth resource invoke someones_drive doc_insert_text_at '{"document_id":"<id>","index":25,"text_json":"\"inserted \""}'

# Delete the content in the range [start, end)
hearth resource invoke someones_drive doc_delete_range '{"document_id":"<id>","start_index":10,"end_index":20}'

# Format a range: style_json is a Docs TextStyle object, fields names what you set
hearth resource invoke someones_drive doc_format_text '{"document_id":"<id>","start_index":1,"end_index":12,"style_json":"{\"bold\":true}","fields":"bold"}'
hearth resource invoke someones_drive doc_format_text '{"document_id":"<id>","start_index":1,"end_index":40,"style_json":"{\"link\":{\"url\":\"https://example.com\"}}","fields":"link"}'
```

`style_json` is a raw JSON object (a Docs `TextStyle`); `fields` must name
exactly the keys you set. This verb is character styling only — headings and
other paragraph styles aren't exposed.

### Sheets tab management

`sheet_id` is the numeric id from `sheet_get` (not the tab's title):

```
hearth resource invoke someones_drive sheet_duplicate_tab '{"spreadsheet_id":"<id>","sheet_id":0,"new_title":"2027 copy"}'
hearth resource invoke someones_drive sheet_delete_tab '{"spreadsheet_id":"<id>","sheet_id":123456}'
```

### What you can reach

This connection acts as the impersonated Workspace user through a service
account with full Drive access, so **every** verb — the `doc_*`/`sheet_*`/
`slides_*` editors *and* the Drive-level operations (`search_files`,
`export_file`, `download_file`, etc.) — works on any file that user can access,
including files they created by hand.

## File IDs vs names

Drive uses opaque file IDs, not paths. Whenever you need to act on a file
you haven't seen yet:
1. `search_files` or `list_folder_contents` to find it
2. Copy the `id` from the result
3. Pass that `id` to the target verb

Never guess or construct a file ID.

## list_files returns 50 results

`list_files` returns the 50 most recently modified non-trashed files. There
is no pagination in v1. For targeted results, use `search_files` or
`list_folder_contents` instead.
